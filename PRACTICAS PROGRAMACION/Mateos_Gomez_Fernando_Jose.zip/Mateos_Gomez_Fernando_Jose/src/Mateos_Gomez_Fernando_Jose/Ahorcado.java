//NombreAutor: Fernando Mateos Gomez
package Mateos_Gomez_Fernando_Jose;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;

public class Ahorcado {

    private LinkedList<Character> palabraC, palabra;
    private byte errores;

    public byte getErrores() {
        return this.errores;
    }

    public LinkedList<Character> getPalabraC() {
        return palabraC;
    }

    
    public static String seleccionaPalabra(byte dificultad) throws IOException, FileNotFoundException, NumberFormatException {
        //Entorno:
        int j;
        String i;
        int palElegida;
        String nPalabras;
        Random palAleatoria;
        String palabra;
        String nombre_fichero;
        BufferedReader archivoDif = null;
        //Algoritmo:
        if (dificultad == 1) {
            nombre_fichero = "Facil.txt";
        } else {
            nombre_fichero = "Dificil.txt";
        }//Fin Si
        palabra = new String();
        nPalabras = new String();
        j = 0;
        archivoDif = new BufferedReader(new FileReader(new File("NIVELES_DE_DIF", nombre_fichero)));
        nPalabras = archivoDif.readLine().trim();
        palAleatoria = new Random();
        palElegida = palAleatoria.nextInt(Integer.parseInt(nPalabras));
        j = 0;
        palabra = archivoDif.readLine();
        while (j < palElegida) {
            j++;
            palabra = archivoDif.readLine();
        }
        if (archivoDif != null) {
            archivoDif.close();
        }
        if (palabra == null) {
            throw new NumberFormatException("");
        }
        return palabra.trim();
    }

    public Ahorcado(String palabraSecreta)  {
        String palabra = palabraSecreta;
        byte i;
        this.palabraC = new LinkedList<Character>();
        this.palabra = new LinkedList<Character>();
        for (i = 0; i < palabra.length(); i++) {
            this.palabra.add(palabra.charAt(i));
            this.palabraC.add('*');
        }//Fin Para
    }

    public LinkedList<Character> getPalabra() {
        return palabra;
    }

    public void jugar(char letra) {
        if (this.palabra.contains(letra)) {
            this.arreglaPalabra(letra);
        } else {
            this.errores++;
        }//Fin Si
        System.out.println("PALABRA SECRETA: " + this.getPalabraC().toString().substring(1, this.getPalabraC().toString().length() - 1).replaceAll(",", " "));
        System.out.println("ERRORES: " + this.errores);
    }

    private void arreglaPalabra(char letra) {
        byte i;
        for (i = 0; i < this.palabra.size(); i++) {
            if (this.palabra.get(i) == letra) {
                this.palabraC.set(i, letra);
            }//Fin Si
        }
    }

    public boolean haGanado() {
        return this.getPalabraC().toString().equals(this.getPalabra().toString());
    }
}
