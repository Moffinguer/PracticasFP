//NombreAutor: Fernando Mateos Gomez
package Mateos_Gomez_Fernando_Jose;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;

public class AhorcadoFacil extends Ahorcado {

    private LinkedList<Character> errores;

    public AhorcadoFacil(String palabraSecreta) {
        super(palabraSecreta);
        this.errores = new LinkedList<Character>();
    }

    @Override
    public byte getErrores() {
        return (byte) this.errores.size();
    }

    @Override
    public void jugar(char letra) {
        if (this.getPalabra().contains(letra)) {
            this.arreglaPalabra(letra);
        } else {
            if (this.errores.contains(letra)) {
                System.out.println("NO PUEDES REPETIR ESA LETRA");
            } else {
                this.aniadeError(letra);
            }//Fin Si
        }//Fin Si
        System.out.println("PALABRA SECRETA: " + this.getPalabraC().toString().substring(1, this.getPalabraC().toString().length() - 1).replaceAll(",", " "));
        System.out.println("LISTA LETRAS ERRONEAS: " + this.errores.toString());
        System.out.println("INTENTOS: " + (10 - this.errores.size()));
    }

    private void arreglaPalabra(char letra) {
        byte i;
        for (i = 0; i < this.getPalabra().size(); i++) {
            if (this.getPalabra().get(i) == letra) {
                this.getPalabraC().set(i, letra);
            }//Fin Si
        }
    }

    private void aniadeError(char letra) {

        this.errores.add(letra);
    }
}
