//NombreAutor: Fernando Mateos Gomez
package Mateos_Gomez_Fernando_Jose;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class JuegoAhorcado {

    public static void main(String[] args) {
        //Entorno:
        Ahorcado nivelDif;
        boolean intentosPasados, conErrores;
        String palSecreta;
        byte opcion;
        String sOpcion;
        BufferedReader teclado;
        char letra;
        String opcionLetra;
        //Algoritmo:
        opcion = 0;
        sOpcion = "";
        try {
            do {
                try {
                    teclado = new BufferedReader(new InputStreamReader(System.in));
                    System.out.println("Nivel 1.- F�cil");
                    System.out.println("Nivel 2.- Dif�cil");
                    System.out.print("Elige opci�n: ");
                    sOpcion = teclado.readLine();
                    opcion = (byte) Integer.parseInt(sOpcion);
                    conErrores = false;
                } catch (NumberFormatException nfe) {
                    System.err.println("");
                    conErrores = true;
                }
            } while (conErrores || (opcion != 1 && opcion != 2));
            if (opcion == 1) {
                nivelDif = new AhorcadoFacil(Ahorcado.seleccionaPalabra(opcion));
            } else {
                nivelDif = new Ahorcado(Ahorcado.seleccionaPalabra(opcion));
            }//Fin Si
            opcionLetra = new String();
            System.out.println("PALABRA SECRETA: " + nivelDif.getPalabraC().toString().substring(1, nivelDif.getPalabraC().toString().length() - 1).replaceAll(",", " "));
            do {
                letra = 'a';
                do {
                    do {
                        do {

                            System.out.println("Introduce una LETRA en MAYUSCULA para jugar: ");
                            teclado = new BufferedReader(new InputStreamReader(System.in));
                            opcionLetra = teclado.readLine();
                        } while (opcionLetra.length() > 1 || opcionLetra == null);
                        letra = opcionLetra.charAt(0);
                    } while (letra < 'A' || letra > 'Z');
                    try {

                        conErrores = false;
                    } catch (StringIndexOutOfBoundsException sioobe) {
                        System.err.println("CARACTER INV�LIDO");
                        conErrores = true;
                    }
                } while (conErrores);
                nivelDif.jugar(letra);
                intentosPasados = nivelDif.getErrores() < 10;
            } while (intentosPasados && !nivelDif.haGanado());
            if (intentosPasados) {
                System.out.println("ENHORABUENA HAS GANADO");
            } else {
                System.out.println("HAS PERDIDO. LA PALABRA SECRETA ERA \"" + nivelDif.getPalabra().toString().substring(1, nivelDif.getPalabra().toString().length() - 1).replaceAll(",", " ")+"\"");
            }//Fin Si
        } catch (NumberFormatException nfe) {
            String fichero="Dificil.txt";
            if(opcion==1){
             fichero="Facil.txt";   
            }
            System.err.println("El fichero "+fichero+" tiene un formato incorrecto");
        } catch (FileNotFoundException fnfe) {
            System.err.println("Archivo no encontrado, contacte con su administrador.");
        } catch (IOException ioe) {
            System.err.println("Error al introducir datos, compruebe que su dispositivo est� conectado. En caso contrario llame al administrador.");
        }
    }
}
